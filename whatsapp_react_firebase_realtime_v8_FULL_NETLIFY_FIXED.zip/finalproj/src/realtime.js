import { ref, set, update, remove, onValue, onDisconnect, push, serverTimestamp as rtdbServerTimestamp } from 'firebase/database';
import { db, database } from './firebase';

// Internal RTDB handle. It is intentionally not exported; UI code imports the
// database instance directly from firebase.js to avoid stale named-export builds.
const rtdb = database;

import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';

export function watchPresence(uid, callback) {
  const statusRef = ref(rtdb, `status/${uid}`);
  return onValue(statusRef, snap => {
    const value = snap.val() || {};
    const connections = value.connections || {};
    const online = Object.keys(connections).length > 0;
    callback({ online, lastSeen: value.lastOnline || null });
  });
}

export function startPresence(uid) {
  const connectedRef = ref(rtdb, '.info/connected');
  let currentConnection = null;
  const unsub = onValue(connectedRef, async snap => {
    if (snap.val() !== true) { currentConnection = null; return; }
    if (currentConnection) return;
    const connectionRef = push(ref(rtdb, `status/${uid}/connections`));
    currentConnection = connectionRef;
    try {
      await onDisconnect(connectionRef).remove();
      await onDisconnect(ref(rtdb, `status/${uid}/lastOnline`)).set(rtdbServerTimestamp());
      await set(connectionRef, true);
      await update(ref(rtdb, `status/${uid}`), { state: 'online' });
    } catch {
      currentConnection = null;
    }
  });
  return () => {
    unsub();
    currentConnection = null;
  };
}

export function chatIdFor(a, b) {
  return [a, b].sort().join('_');
}

export async function ensureChat(chatId, me, other) {
  const chatRef = doc(db, 'chats', chatId);
  await setDoc(chatRef, {
    participants: [me.uid, other.uid].sort(),
    participantProfiles: {
      [me.uid]: { name: me.name || 'User', photo: me.photo || '' },
      [other.uid]: { name: other.name || 'User', photo: other.photo || '' },
    },
    updatedAt: serverTimestamp(),
    lastMessage: '',
    lastSenderId: '',
  }, { merge: true });
}

export async function findPublicProfile(uid) {
  const snap = await getDoc(doc(db, 'publicProfiles', uid));
  return snap.exists() ? { uid, ...snap.data() } : null;
}

export async function upsertPublicProfile(uid, profile) {
  await setDoc(doc(db, 'publicProfiles', uid), {
    name: profile.name || 'User',
    about: profile.about || '',
    phone: profile.phone || '',
    photo: profile.photo || '',
    username: profile.username || '',
    links: profile.links || '',
    updatedAt: serverTimestamp(),
  }, { merge: true });
}

export function watchTyping(chatId, otherUid, callback) {
  return onValue(ref(rtdb, `typing/${chatId}/${otherUid}`), snap => callback(snap.val() === true));
}

export async function setTyping(chatId, uid, value) {
  const typingRef = ref(rtdb, `typing/${chatId}/${uid}`);
  if (value) {
    await onDisconnect(typingRef).remove();
    await set(typingRef, true);
  } else {
    await remove(typingRef);
  }
}

export function callRef(callId) { return ref(rtdb, `calls/${callId}`); }
export function callIceRef(callId, side) { return ref(rtdb, `calls/${callId}/ice/${side}`); }
export { ref, set, update, remove, onValue, push, rtdbServerTimestamp };
