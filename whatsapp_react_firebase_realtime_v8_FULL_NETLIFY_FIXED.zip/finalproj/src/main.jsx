import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import Cropper from "react-easy-crop";
import {
  auth,
  db,
  storage,
  firebaseConfig,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  onAuthStateChanged,
  signOut,
  signInAnonymously,
} from "./firebase";
import { collection, doc, getDoc, getDocs, setDoc, updateDoc, addDoc, query, where, onSnapshot, orderBy, limit, serverTimestamp, writeBatch, deleteDoc } from "firebase/firestore";
import { ref, uploadString, getDownloadURL } from "firebase/storage";
import { chatIdFor, ensureChat, findPublicProfile, upsertPublicProfile, watchPresence, startPresence, watchTyping, setTyping, callRef, callIceRef, ref as rtdbRef, set as rtdbSet, update as rtdbUpdate, onValue as rtdbOnValue, push as rtdbPush } from "./realtime";
import { database as rtdb } from "./firebase";
import { arrayUnion } from "firebase/firestore";
import "./styles.css";

const LS = "wa-upgraded-local-v3";
const defaultProfile = {
  name: "RIGHT",
  about: "Hey there! I am using WhatsApp Style.",
  username: "no_name_12345",
  phone: "",
  links: "",
  photo: "",
};

function loadLocal() {
  try { return JSON.parse(localStorage.getItem(LS) || "{}"); } catch { return {}; }
}
function saveLocal(value) { localStorage.setItem(LS, JSON.stringify(value)); }

function App() {
  const initial = loadLocal();
  const [user, setUser] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [page, setPage] = useState("chats");
  const [menu, setMenu] = useState(false);
  const [local, setLocal] = useState(initial);
  const [profile, setProfile] = useState({ ...defaultProfile, ...(initial.profile || {}) });
  const [lockEnabled, setLockEnabled] = useState(!!initial.lockEnabled);
  const [unlocked, setUnlocked] = useState(!initial.lockEnabled);
  const [toast, setToast] = useState("");
  const [ai, setAi] = useState(initial.ai || []);
  const [aiText, setAiText] = useState("");
  const [aiBusy, setAiBusy] = useState(false);
  const [settings, setSettings] = useState({
    theme: "system", language: "English", reducedMotion: false, highContrast: false, largeText: false,
    notifications: true, messagePreview: true, sounds: true, dataSaver: false, autoDownloadMedia: true,
    readReceipts: true, lastSeen: "Everyone", profilePhotoVisibility: "Everyone", enterToSend: true, mediaVisibility: true,
    ...(initial.settings || {})
  });
  const [cropSrc, setCropSrc] = useState("");
  const [showCrop, setShowCrop] = useState(false);
  const [activeChat, setActiveChat] = useState(null);
  const [incomingCall, setIncomingCall] = useState(null);
  const fileRef = useRef(null);

  useEffect(() => onAuthStateChanged(auth, async (u) => {
    setUser(u); setAuthReady(true);
    if (!u) return;
    try {
      const snap = await getDoc(doc(db, "users", u.uid));
      const saved = snap.exists() ? (snap.data().profile || {}) : {};
      const p = { ...defaultProfile, ...saved, phone: u.phoneNumber || saved.phone || "" };
      setProfile(p); updateLocal({ profile: p });
      if (!snap.exists()) await setDoc(doc(db, "users", u.uid), { profile: p, createdAt: serverTimestamp(), updatedAt: serverTimestamp() }, { merge: true });
      await upsertPublicProfile(u.uid, p);
      await startPresence(u.uid);
    } catch (error) { notify(`Firebase sync failed: ${error.message}`); }
  }), []);

  useEffect(() => { if (!user) return; const c = rtdbOnValue(callRef("incoming"), () => {}); return () => c(); }, [user]);
  useEffect(() => { if (toast) { const t = setTimeout(() => setToast(""), 2600); return () => clearTimeout(t); } }, [toast]);
  useEffect(() => setUnlocked(!lockEnabled), [lockEnabled]);

  function updateLocal(extra = {}) { setLocal(current => { const next = { ...current, ...extra }; saveLocal(next); return next; }); }
  function updateSettings(patch) { setSettings(current => { const next = { ...current, ...patch }; updateLocal({ settings: next }); return next; }); }
  function notify(message) { setToast(message); }
  async function saveProfile(nextProfile) {
    setProfile(nextProfile); updateLocal({ profile: nextProfile });
    if (user) {
      await setDoc(doc(db, "users", user.uid), { profile: nextProfile, updatedAt: serverTimestamp() }, { merge: true });
      await upsertPublicProfile(user.uid, nextProfile);
    }
  }
  function setAppLock(enabled) { setLockEnabled(enabled); updateLocal({ lockEnabled: enabled }); setUnlocked(!enabled); }
  async function logout() { try { await signOut(auth); setPage("chats"); notify("Signed out"); } catch (e) { notify(e.message || "Sign out failed"); } }

  if (!authReady) return <Splash text="Starting secure session…" />;
  if (!user) return <LoginScreen />;
  if (lockEnabled && !unlocked) return <BiometricLock onUnlock={() => setUnlocked(true)} onDisable={() => setAppLock(false)} />;

  const me = { uid: user.uid, name: profile.name || "User", photo: profile.photo || "" };
  const appClass = `app theme-${settings.theme || "system"} ${settings.largeText ? "large-text" : ""} ${settings.highContrast ? "high-contrast" : ""} ${settings.reducedMotion ? "reduced-motion" : ""}`;
  return <div className={appClass}>
    <CallManager me={me} />
    {page === "chats" && <Chats me={me} profile={profile} onMeta={() => setPage("meta")} onMenu={() => setMenu(true)} onNotify={notify} onOpenChat={(chat) => { setActiveChat(chat); setPage("chat"); }} />}
    {page === "chat" && activeChat && <ChatScreen me={me} chat={activeChat} onBack={() => { setActiveChat(null); setPage("chats"); }} onNotify={notify} />}
    {page === "updates" && <Updates profile={profile} onNotify={notify} />}
    {page === "communities" && <Communities onNotify={notify} />}
    {page === "calls" && <Calls me={me} onNotify={notify} onOpenChat={(chat) => { setActiveChat(chat); setPage("chat"); }} />}
    {page === "settings" && <Settings profile={profile} onBack={() => setPage("chats")} onProfile={() => setPage("profile")} onPrivacy={() => setPage("privacy")} onChats={() => setPage("chat-settings")} onOpen={(p) => setPage(p)} onNotify={notify} onLogout={logout} />}
    {page === "profile" && <Profile profile={profile} user={user} onBack={() => setPage("settings")} onSave={saveProfile} fileRef={fileRef} cropSrc={cropSrc} setCropSrc={setCropSrc} showCrop={showCrop} setShowCrop={setShowCrop} />}
    {page === "privacy" && <Privacy lockEnabled={lockEnabled} setLock={setAppLock} onBack={() => setPage("settings")} onNotify={notify} />}
    {page === "chat-settings" && <ChatSettings settings={settings} updateSettings={updateSettings} lockEnabled={lockEnabled} setLock={setAppLock} onBack={() => setPage("settings")} onNotify={notify} />}
    {page.startsWith("settings-") && <SettingsDetail type={page.slice(9)} settings={settings} updateSettings={updateSettings} profile={profile} onBack={() => setPage("settings")} onNotify={notify} />}
    {page === "meta" && <MetaAI messages={ai} setMessages={(m) => { setAi(m); updateLocal({ ai: m }); }} text={aiText} setText={setAiText} busy={aiBusy} setBusy={setAiBusy} onBack={() => setPage("chats")} />}
    {menu && <SideMenu close={() => setMenu(false)} setPage={(p) => { setMenu(false); setPage(p); }} notify={notify} />}
    {incomingCall && <IncomingCallBanner call={incomingCall} me={me} onClose={() => setIncomingCall(null)} />}
    {!['settings','profile','privacy','chat-settings','meta','chat'].includes(page) && !page.startsWith('settings-') && <Bottom page={page} setPage={setPage} />}
    {toast && <div className="toast">{toast}</div>}
  </div>;
}

function IncomingCallBanner({ call, me, onClose }) {
  return <div className="incoming-call"><div><b>Incoming {call.kind === "video" ? "video" : "voice"} call</b><small>{call.callerName || "Contact"}</small></div><button className="danger" onClick={onClose}>Decline</button><button className="green" onClick={() => { window.dispatchEvent(new CustomEvent("accept-firebase-call", { detail: call })); onClose(); }}>Accept</button></div>;
}

function Splash({ text }) {
  return <div className="splash"><div className="logo">◉</div><b>WhatsApp Style</b><span>{text}</span></div>;
}

function LoginScreen() {
  const countries = [
    { name: "India", flag: "🇮🇳", code: "+91", digits: 10 },
    { name: "Pakistan", flag: "🇵🇰", code: "+92", digits: 10 },
    { name: "Bangladesh", flag: "🇧🇩", code: "+880", digits: 10 },
    { name: "Nepal", flag: "🇳🇵", code: "+977", digits: 10 },
    { name: "United States", flag: "🇺🇸", code: "+1", digits: 10 },
    { name: "United Kingdom", flag: "🇬🇧", code: "+44", digits: 10 },
    { name: "United Arab Emirates", flag: "🇦🇪", code: "+971", digits: 9 },
    { name: "Australia", flag: "🇦🇺", code: "+61", digits: 9 },
  ];

  const [country, setCountry] = useState(countries[0]);
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [captcha, setCaptcha] = useState("");
  const [captchaText, setCaptchaText] = useState(() => makeCaptcha());
  const [otpCode, setOtpCode] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  function makeCaptcha() {
    return String(Math.floor(1000 + Math.random() * 9000));
  }

  function refreshCaptcha() {
    setCaptcha("");
    setCaptchaText(makeCaptcha());
  }

  function cleanDigits(value) {
    return value.replace(/\D/g, "");
  }

  function validatePhone() {
    const digits = cleanDigits(phone);
    return digits.length === country.digits;
  }

  async function send() {
    setErr("");
    const digits = cleanDigits(phone);

    if (digits.length !== country.digits) {
      setErr(`Enter a valid ${country.digits}-digit mobile number.`);
      return;
    }

    if (cleanDigits(captcha) !== captchaText) {
      setErr("CAPTCHA is incorrect. Enter the code shown above.");
      refreshCaptcha();
      return;
    }

    setBusy(true);
    try {
      // Generate a fresh 6-digit code every time the user requests a login code.
      // Demo mode: the code is displayed on screen instead of being sent by SMS.
      const freshCode = String(Math.floor(100000 + Math.random() * 900000));
      setOtpCode(freshCode);
      setSent(true);
      setCode("");
      setErr("");
    } finally {
      setBusy(false);
    }
  }

  async function verify() {
    setErr("");

    if (!otpCode || code !== otpCode) {
      setErr("Wrong verification code. Use the new 6-digit code shown above.");
      return;
    }

    setBusy(true);
    try {
      // Create a Firebase session so the existing app/database/profile system
      // continues to work without requiring an SMS OTP.
      await signInAnonymously(auth);
    } catch (e) {
      setErr(friendlyFirebaseError(e));
    } finally {
      setBusy(false);
    }
  }

  const fullPhone = `${country.code}${cleanDigits(phone)}`;

  return (
    <div className="auth">
      <div className="auth-card login-modern">
        <div className="login-logo">◉</div>
        <div className="brand">WhatsApp Style</div>

        {!sent ? (
          <>
            <h1>Login to continue</h1>
            <p>Select your region, enter your mobile number, complete CAPTCHA, then continue.</p>

            <label>Country / Region</label>
            <select
              className="country-select"
              value={country.code}
              onChange={(e) => {
                const next = countries.find((c) => c.code === e.target.value) || countries[0];
                setCountry(next);
                setPhone("");
                setErr("");
              }}
            >
              {countries.map((c) => (
                <option key={`${c.name}-${c.code}`} value={c.code}>
                  {c.flag} {c.name} ({c.code})
                </option>
              ))}
            </select>

            <label>Mobile number</label>
            <div className="phone-row">
              <div className="dial-code">{country.code}</div>
              <input
                value={phone}
                onChange={(e) => setPhone(cleanDigits(e.target.value).slice(0, country.digits))}
                placeholder={country.digits === 10 ? "9876543210" : "Mobile number"}
                inputMode="numeric"
                autoComplete="tel"
              />
            </div>

            <div className="captcha-card">
              <div>
                <small>CAPTCHA</small>
                <strong>{captchaText}</strong>
              </div>
              <button type="button" className="captcha-refresh" onClick={refreshCaptcha} aria-label="Refresh CAPTCHA">↻</button>
            </div>

            <label>Enter CAPTCHA</label>
            <input
              value={captcha}
              onChange={(e) => setCaptcha(cleanDigits(e.target.value).slice(0, 4))}
              placeholder="Enter 4-digit CAPTCHA"
              inputMode="numeric"
            />

            <button
              className="green"
              disabled={busy || !validatePhone() || captcha.length !== 4}
              onClick={send}
            >
              {busy ? "Please wait…" : "Continue"}
            </button>
          </>
        ) : (
          <>
            <div className="code-banner">
              <span>YOUR 6-DIGIT LOGIN CODE</span>
              <strong>{otpCode}</strong>
            </div>

            <h1>Enter verification code</h1>
            <p>New code for <b>{fullPhone}</b></p>

            <label>6-digit code</label>
            <input
              className="otp-input"
              value={code}
              onChange={(e) => setCode(cleanDigits(e.target.value).slice(0, 6))}
              placeholder="123456"
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={6}
            />

            <button
              className="green"
              disabled={busy || code.length !== 6}
              onClick={verify}
            >
              {busy ? "Opening app…" : "Verify & Open App"}
            </button>

            <button
              className="textbtn"
              onClick={() => {
                setSent(false);
                setCode("");
                setOtpCode("");
                setErr("");
                refreshCaptcha();
              }}
            >
              ← Change number
            </button>
          </>
        )}

        {err && <div className="error">{err}</div>}
        <p className="tiny login-note">
          Demo login mode: a new 6-digit code is generated each time you request login. It is shown on screen and is not sent by SMS.
          For production security, use Firebase Phone Authentication with real SMS OTP.
        </p>
      </div>
    </div>
  );
}

function friendlyFirebaseError(error) {
  const code = error?.code || "";
  const map = {
    "auth/invalid-phone-number": "Invalid phone number. Use international format like +919876543210.",
    "auth/too-many-requests": "Too many attempts. Please wait and try again later.",
    "auth/quota-exceeded": "SMS quota exceeded for this Firebase project.",
    "auth/invalid-verification-code": "That verification code is incorrect.",
    "auth/code-expired": "That code expired. Request a new code.",
    "auth/operation-not-allowed": "The required Firebase sign-in provider is not enabled. Enable Anonymous Authentication in Firebase Console.",
    "auth/admin-restricted-operation": "Anonymous sign-in is disabled. Enable Anonymous Authentication in Firebase Console.",
    "auth/unauthorized-domain": "This domain is not authorized in Firebase Authentication.",
  };
  return map[code] || error?.message || "Firebase authentication failed.";
}

async function registerWebAuthn() {
  if (!window.PublicKeyCredential || !window.isSecureContext) throw new Error("Biometric unlock needs HTTPS (or localhost) and a WebAuthn-capable browser.");
  const challenge = crypto.getRandomValues(new Uint8Array(32));
  const credential = await navigator.credentials.create({ publicKey: {
    challenge,
    rp: { name: "WhatsApp Style App", id: location.hostname },
    user: { id: crypto.getRandomValues(new Uint8Array(16)), name: `device-${Date.now()}`, displayName: "Device user" },
    pubKeyCredParams: [{ alg: -7, type: "public-key" }, { alg: -257, type: "public-key" }],
    authenticatorSelection: { authenticatorAttachment: "platform", userVerification: "required" },
    timeout: 60000,
  }});
  localStorage.setItem("waWebAuthn", JSON.stringify({ id: credential.id, created: Date.now() }));
}

async function useWebAuthn() {
  if (!window.PublicKeyCredential || !window.isSecureContext) throw new Error("WebAuthn is unavailable in this context.");
  const raw = localStorage.getItem("waWebAuthn");
  if (!raw) throw new Error("No biometric credential enrolled.");
  const stored = JSON.parse(raw);
  const challenge = crypto.getRandomValues(new Uint8Array(32));
  await navigator.credentials.get({ publicKey: {
    challenge,
    rpId: location.hostname,
    allowCredentials: [{ id: base64urlToBytes(stored.id), type: "public-key" }],
    userVerification: "required",
    timeout: 60000,
  }});
}
function base64urlToBytes(value) {
  const padded = value + "=".repeat((4 - value.length % 4) % 4);
  const decoded = atob(padded.replace(/-/g, "+").replace(/_/g, "/"));
  return Uint8Array.from(decoded, (c) => c.charCodeAt(0));
}

function BiometricLock({ onUnlock, onDisable }) {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("Use fingerprint, face unlock, or your device PIN/security key.");
  const [has, setHas] = useState(!!localStorage.getItem("waWebAuthn"));
  async function unlock() {
    setBusy(true);
    try { await useWebAuthn(); onUnlock(); } catch (e) { setMsg(e.message || "Unlock failed"); }
    finally { setBusy(false); }
  }
  async function enroll() {
    setBusy(true);
    try { await registerWebAuthn(); setHas(true); setMsg("Device credential enrolled. Tap Unlock."); }
    catch (e) { setMsg(e.message || "Enrollment failed"); }
    finally { setBusy(false); }
  }
  return <div className="lock"><div className="lock-card"><div className="lock-icon">🔒</div><h1>App locked</h1><p>{msg}</p>{!has ? <button className="green" disabled={busy} onClick={enroll}>{busy ? "Waiting…" : "Set up biometric / device lock"}</button> : <button className="green" disabled={busy} onClick={unlock}>{busy ? "Checking…" : "Unlock with biometrics"}</button>}<button className="textbtn" onClick={onDisable}>Disable app lock</button></div></div>;
}

function Chats({ me, profile, onMeta, onMenu, onNotify, onOpenChat }) {
  const [chats, setChats] = useState([]);
  const [showNew, setShowNew] = useState(false);
  const [target, setTarget] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    const q = query(collection(db, "chats"), where("participants", "array-contains", me.uid), limit(100));
    return onSnapshot(q, snap => {
      const rows = snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a,b) => (b.updatedAt?.seconds || 0) - (a.updatedAt?.seconds || 0));
      setChats(rows);
    }, e => onNotify(`Chat sync error: ${e.message}`));
  }, [me.uid]);
  async function createChat() {
    const value = target.trim();
    if (!value || value === me.uid) return;
    setBusy(true);
    try {
      const other = await findPublicProfile(value);
      if (!other) throw new Error("User not found. Enter the other user's Firebase UID.");
      const otherUser = { uid: other.uid, name: other.name, photo: other.photo };
      const chatId = chatIdFor(me.uid, other.uid);
      await ensureChat(chatId, me, otherUser);
      setShowNew(false); setTarget(""); onOpenChat({ id: chatId, other: otherUser });
    } catch (e) { onNotify(e.message); } finally { setBusy(false); }
  }
  return <section className="screen">
    <header><h1>Chats</h1><div className="head-actions"><button onClick={() => setShowNew(true)}>✎</button><button onClick={onMenu}>⋮</button></div></header>
    <div className="search" onClick={onMeta}>⌕ <input readOnly placeholder="Ask Meta AI or Search" /></div>
    <div className="pills"><span className="active">All</span><span>Favourites</span><span>Groups</span><span onClick={() => setShowNew(true)}>＋</span></div>
    <button className="chat-row" onClick={onMeta}><div className="ai-avatar">✦</div><div><b>Meta AI ✓</b><small>Ask Meta AI anything…</small></div><time>Now</time></button>
    {chats.length === 0 && <div className="empty">No real-time chats yet.<br /><small>Tap ✎ and enter another user's Firebase UID.</small></div>}
    {chats.map(chat => {
      const otherUid = chat.participants?.find(x => x !== me.uid);
      const other = chat.participantProfiles?.[otherUid] || { name: "Contact", photo: "" };
      return <button className="chat-row" key={chat.id} onClick={() => onOpenChat({ id: chat.id, other: { uid: otherUid, ...other } })}>
        <div className="avatar">{other.photo ? <img src={other.photo} /> : (other.name || "U").slice(0,1)}</div>
        <div><b>{other.name || "Contact"}</b><small>{chat.lastMessage || "No messages yet"}</small></div>
        <time>{formatTime(chat.updatedAt)}</time>
      </button>;
    })}
    {showNew && <div className="dialog-overlay"><div className="dialog"><h2>New chat</h2><p>Enter the other user's Firebase UID.</p><input autoFocus value={target} onChange={e => setTarget(e.target.value)} placeholder="e.g. 8Xy...uid" /><div className="dialog-actions"><button onClick={() => setShowNew(false)}>Cancel</button><button className="green" disabled={busy} onClick={createChat}>{busy ? "Opening…" : "Open chat"}</button></div></div></div>}
  </section>;
}

function formatTime(ts) {
  if (!ts) return "";
  const d = ts.toDate ? ts.toDate() : new Date(ts);
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function ChatScreen({ me, chat, onBack, onNotify }) {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [otherOnline, setOtherOnline] = useState(false);
  const [typing, setTypingState] = useState(false);
  const [sending, setSending] = useState(false);
  const typingTimer = useRef(null);
  const bottomRef = useRef(null);
  const other = chat.other;
  useEffect(() => {
    const q = query(collection(db, `chats/${chat.id}/messages`), orderBy("createdAt", "asc"), limit(500));
    return onSnapshot(q, async snap => {
      const rows = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setMessages(rows);
      const unread = rows.filter(m => m.senderId !== me.uid && !(m.readBy || []).includes(me.uid));
      if (unread.length) {
        const batch = writeBatch(db);
        unread.forEach(m => batch.update(doc(db, `chats/${chat.id}/messages`, m.id), { readBy: arrayUnion(me.uid), readAt: serverTimestamp() }));
        try { await batch.commit(); } catch {}
      }
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 0);
    }, e => onNotify(`Message sync error: ${e.message}`));
  }, [chat.id, me.uid]);
  useEffect(() => watchPresence(other.uid, setOtherOnline), [other.uid]);
  useEffect(() => watchTyping(chat.id, other.uid, setTypingState), [chat.id, other.uid]);
  useEffect(() => () => { if (typingTimer.current) clearTimeout(typingTimer.current); setTyping(chat.id, me.uid, false).catch(() => {}); }, [chat.id, me.uid]);

  async function send() {
    const body = text.trim(); if (!body || sending) return;
    setSending(true);
    try {
      const now = serverTimestamp();
      const messageRef = await addDoc(collection(db, `chats/${chat.id}/messages`), { senderId: me.uid, text: body, createdAt: now, readBy: [me.uid], type: "text" });
      await updateDoc(doc(db, "chats", chat.id), { lastMessage: body, lastSenderId: me.uid, updatedAt: now });
      setText(""); await setTyping(chat.id, me.uid, false);
      if (messageRef) bottomRef.current?.scrollIntoView({ behavior: "smooth" });
    } catch (e) { onNotify(`Send failed: ${e.message}`); } finally { setSending(false); }
  }
  function input(v) {
    setText(v);
    setTyping(chat.id, me.uid, !!v.trim()).catch(() => {});
    if (typingTimer.current) clearTimeout(typingTimer.current);
    if (v.trim()) typingTimer.current = setTimeout(() => setTyping(chat.id, me.uid, false).catch(() => {}), 1800);
  }
  function startCall(kind) { window.dispatchEvent(new CustomEvent("start-firebase-call", { detail: { other, kind, me } })); }
  return <section className="screen chat-screen">
    <div className="chat-header"><button onClick={onBack}>‹</button><div className="avatar small">{other.photo ? <img src={other.photo} /> : (other.name || "U").slice(0,1)}</div><div className="chat-title"><b>{other.name || "Contact"}</b><small>{typing ? "typing…" : otherOnline ? "online" : "offline"}</small></div><button onClick={() => startCall("audio")}>☎</button><button onClick={() => startCall("video")}>▣</button><button>⋮</button></div>
    <div className="messages">{messages.map(m => <MessageBubble key={m.id} message={m} mine={m.senderId === me.uid} />)}{typing && <div className="typing-bubble">typing…</div>}<div ref={bottomRef} /></div>
    <div className="composer"><button>＋</button><input value={text} onChange={e => input(e.target.value)} onKeyDown={e => e.key === "Enter" && send()} placeholder="Message" /><button onClick={send} disabled={sending || !text.trim()}>➤</button></div>
  </section>;
}

function MessageBubble({ message, mine }) {
  const read = mine && (message.readBy || []).length > 1;
  return <div className={`message-line ${mine ? "mine" : "theirs"}`}><div className="message-bubble">{message.text}<span>{formatTime(message.createdAt)} {mine && <b className={read ? "read" : ""}>✓✓</b>}</span></div></div>;
}

function Calls({ me, onNotify }) {
  const [history, setHistory] = useState([]);
  useEffect(() => {
    const q = query(collection(db, "callLogs"), where("participants", "array-contains", me.uid), limit(50));
    return onSnapshot(q, snap => setHistory(snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a,b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0))), () => {});
  }, [me.uid]);
  return <section className="screen"><header><h1>Calls</h1><div className="head-actions"><button onClick={() => onNotify("Use a chat to start a call")}>⌕</button><button onClick={() => onNotify("Call settings")}>⋮</button></div></header><div className="call-tools"><button onClick={() => onNotify("Open a chat and tap ☎")}>☎<small>Call</small></button><button onClick={() => onNotify("Schedule calls can be added with Calendar integration")}>▣<small>Schedule</small></button><button onClick={() => onNotify("Keypad opened")}>⠿<small>Keypad</small></button><button onClick={() => onNotify("Favourites opened")}>♡<small>Favourites</small></button></div><h2>Recent</h2>{history.length === 0 ? <div className="empty">No recent calls.</div> : history.map(c => <div className="call-row" key={c.id}><div className="avatar">{(c.otherName || "U").slice(0,1)}</div><div><b>{c.otherName || "Contact"}</b><small>{c.kind === "video" ? "Video" : "Voice"} · {c.status || "ended"}</small></div><time>{formatTime(c.createdAt)}</time></div>)}</section>;
}

function CallManager({ me }) {
  const [call, setCall] = useState(null);
  const [pending, setPending] = useState(null);
  const pcRef = useRef(null);
  const localStreamRef = useRef(null);
  const remoteStreamRef = useRef(null);
  const localVideo = useRef(null);
  const remoteVideo = useRef(null);
  const pendingIce = useRef([]);
  const callStateRef = useRef(null);
  useEffect(() => { callStateRef.current = call; }, [call]);

  useEffect(() => {
    const incomingRef = rtdbRef(rtdb, `incomingCalls/${me.uid}`);
    const unsub = rtdbOnValue(incomingRef, snap => {
      const val = snap.val() || {};
      const first = Object.entries(val).map(([id, v]) => ({ id, ...v })).find(x => x.status === "ringing");
      if (first && !callStateRef.current) setPending(first);
    });
    const start = e => startOutgoing(e.detail).catch(err => alert(err.message));
    const accept = e => { if (e.detail) acceptIncoming(e.detail).catch(err => alert(err.message)); };
    window.addEventListener("start-firebase-call", start);
    window.addEventListener("accept-firebase-call", accept);
    return () => { unsub(); window.removeEventListener("start-firebase-call", start); window.removeEventListener("accept-firebase-call", accept); cleanup(); };
  }, [me.uid]);

  useEffect(() => { if (call?.remoteStream && remoteVideo.current) remoteVideo.current.srcObject = call.remoteStream; if (call?.localStream && localVideo.current) localVideo.current.srcObject = call.localStream; }, [call]);

  async function createPeer(kind, callId, side) {
    const iceServers = [{ urls: "stun:stun.l.google.com:19302" }];
    if (import.meta.env.VITE_TURN_URL) iceServers.push({ urls: import.meta.env.VITE_TURN_URL, username: import.meta.env.VITE_TURN_USERNAME, credential: import.meta.env.VITE_TURN_CREDENTIAL });
    const pc = new RTCPeerConnection({ iceServers });
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: kind === "video" });
    stream.getTracks().forEach(track => pc.addTrack(track, stream));
    const remote = new MediaStream();
    pc.ontrack = e => { e.streams[0]?.getTracks().forEach(t => remote.addTrack(t)); setCall(c => c ? { ...c, remoteStream: remote } : c); };
    pc.onicecandidate = e => { if (e.candidate) rtdbSet(rtdbPush(callIceRef(callId, side)), e.candidate.toJSON()); };
    pcRef.current = pc; localStreamRef.current = stream; remoteStreamRef.current = remote;
    return pc;
  }
  function listenIce(callId, side) {
    return rtdbOnValue(callIceRef(callId, side), async snap => {
      const values = snap.val() || {};
      for (const c of Object.values(values)) {
        try { await pcRef.current?.addIceCandidate(new RTCIceCandidate(c)); } catch {}
      }
    });
  }
  async function startOutgoing({ other, kind }) {
    if (callStateRef.current) return;
    const callId = `${me.uid}_${other.uid}_${Date.now()}`;
    const pc = await createPeer(kind, callId, "caller");
    const offer = await pc.createOffer(); await pc.setLocalDescription(offer);
    const data = { callerId: me.uid, calleeId: other.uid, callerName: me.name, calleeName: other.name, kind, status: "ringing", offer: { type: offer.type, sdp: offer.sdp }, createdAt: Date.now() };
    await rtdbSet(callRef(callId), data);
    await rtdbSet(rtdbRef(rtdb, `incomingCalls/${other.uid}/${callId}`), data);
    const answerUnsub = rtdbOnValue(callRef(callId), async snap => { const v = snap.val(); if (v?.answer && pc.signalingState !== "stable") { try { await pc.setRemoteDescription(new RTCSessionDescription(v.answer)); } catch {} } if (v?.status === "ended") cleanup(); });
    const iceUnsub = listenIce(callId, "callee");
    pc._unsubs = [answerUnsub, iceUnsub];
    setCall({ id: callId, kind, other, localStream: localStreamRef.current, remoteStream: remoteStreamRef.current, direction: "outgoing", status: "ringing" });
  }
  async function acceptIncoming(incoming) {
    setPending(null);
    const callId = incoming.id;
    const pc = await createPeer(incoming.kind, callId, "callee");
    await pc.setRemoteDescription(new RTCSessionDescription(incoming.offer));
    const answer = await pc.createAnswer(); await pc.setLocalDescription(answer);
    await rtdbUpdate(callRef(callId), { answer: { type: answer.type, sdp: answer.sdp }, status: "active" });
    await rtdbSet(rtdbRef(rtdb, `incomingCalls/${me.uid}/${callId}`), { ...incoming, status: "active" });
    const iceUnsub = listenIce(callId, "caller");
    const statusUnsub = rtdbOnValue(callRef(callId), snap => { if (snap.val()?.status === "ended") cleanup(); });
    pc._unsubs = [iceUnsub, statusUnsub];
    const other = { uid: incoming.callerId, name: incoming.callerName || "Contact", photo: "" };
    setCall({ id: callId, kind: incoming.kind, other, localStream: localStreamRef.current, remoteStream: remoteStreamRef.current, direction: "incoming", status: "active" });
  }
  async function hangup() {
    if (!call) return;
    try {
      await rtdbUpdate(callRef(call.id), { status: "ended", endedAt: Date.now() });
      await rtdbSet(rtdbRef(rtdb, `incomingCalls/${call.other.uid}/${call.id}`), null);
      await addDoc(collection(db, "callLogs"), { participants: [me.uid, call.other.uid], otherName: call.other.name || "Contact", kind: call.kind, status: "ended", createdAt: serverTimestamp() });
    } catch {}
    cleanup();
  }
  function cleanup() {
    pcRef.current?._unsubs?.forEach(fn => fn && fn());
    pcRef.current?.close(); pcRef.current = null;
    localStreamRef.current?.getTracks().forEach(t => t.stop()); localStreamRef.current = null;
    remoteStreamRef.current = null; setCall(null); setPending(null);
  }
  return <>{pending && <div className="incoming-call"><div><b>Incoming {pending.kind === "video" ? "video" : "voice"} call</b><small>{pending.callerName}</small></div><button className="danger" onClick={async () => { await rtdbSet(rtdbRef(rtdb, `incomingCalls/${me.uid}/${pending.id}`), null); setPending(null); }}>Decline</button><button className="green" onClick={() => acceptIncoming(pending)}>Accept</button></div>}{call && <div className="call-modal"><div className="call-top"><div><b>{call.kind === "video" ? "Video call" : "Voice call"}</b><small>{call.other.name}</small></div><span>{call.status}</span></div><div className="call-stage">{call.kind === "video" && <><video ref={remoteVideo} autoPlay playsInline className="remote-video" /><video ref={localVideo} autoPlay muted playsInline className="local-video" /></>}{call.kind !== "video" && <div className="voice-avatar">{(call.other.name || "U").slice(0,1)}</div>}</div><div className="call-controls"><button onClick={() => localStreamRef.current?.getAudioTracks().forEach(t => t.enabled = !t.enabled)}>🎙</button>{call.kind === "video" && <button onClick={() => localStreamRef.current?.getVideoTracks().forEach(t => t.enabled = !t.enabled)}>▣</button>}<button className="hangup" onClick={hangup}>☎</button></div></div>}</>;
}

function Bottom({ page, setPage }) { return <nav>{[["chats","▱","Chats"],["updates","◉","Updates"],["communities","♟","Communities"],["calls","☎","Calls"]].map(([p,i,l]) => <button className={page === p ? "navactive" : ""} key={p} onClick={() => setPage(p)}><i>{i}</i><span>{l}</span></button>)}</nav>; }

function SideMenu({ close, setPage, notify }) {
  const items = [
    ["New group", "Group creator opened"],
    ["New community", "Community creator opened"],
    ["Broadcast lists", "Broadcast lists opened"],
    ["Linked devices", "Linked devices opened"],
    ["Starred", "Starred messages opened"],
    ["Payments", "Payments opened"],
    ["Read all", "All chats marked read"],
  ];
  return <div className="overlay" onClick={close}><aside onClick={(e) => e.stopPropagation()}><button className="close" onClick={close}>×</button>{items.map(([label, message]) => <button key={label} onClick={() => { close(); notify(message); }}>{label}</button>)}<hr /><button onClick={() => { close(); setPage("settings"); }}>Settings</button></aside></div>;
}

function Settings({ profile, onBack, onProfile, onPrivacy, onChats, onOpen, onNotify, onLogout }) {
  const rows = [
    ["◇", "Subscriptions", "Premium features and billing", "subscriptions"],
    ["▣", "Linked devices", "Browser/device sessions", "linked-devices"],
    ["⚿", "Account", "Security notifications, change number", "account"],
    ["♙", "Privacy", "Last seen, profile photo, read receipts, app lock", "privacy"],
    ["▤", "Lists", "Manage favourites and contacts", "lists"],
    ["▱", "Chats", "Chat history, backup, enter to send", "chats"],
    ["◉", "Appearance", "Theme, text size and motion", "appearance"],
    ["◌", "Broadcasts", "Create and manage broadcast lists", "broadcasts"],
    ["♧", "Notifications", "Messages, calls and previews", "notifications"],
    ["◔", "Storage and data", "Media download and data saver", "storage"],
    ["♙", "Parental controls", "Local family controls", "parental"],
    ["♿", "Accessibility", "Contrast, text size and animation", "accessibility"],
    ["◎", "App language", "English / Hindi", "language"],
    ["?", "Help and feedback", "Help centre and diagnostics", "help"],
    ["♧", "Invite a friend", "Share this app", "invite"],
    ["∞", "Accounts Centre", "Meta account settings", "accounts-centre"],
  ];
  return <section className="screen"><div className="backbar"><button onClick={onBack}>‹</button><h1>Settings</h1></div><button className="settings-profile" onClick={onProfile}><div className="avatar">{profile.photo ? <img src={profile.photo} /> : profile.name?.[0] || "R"}</div><div><b>{profile.name || "RIGHT"}</b><small>@{profile.username || "no_name_12345"}</small></div></button>{rows.map(([ic,l,d,route]) => <button className="setting-row" key={l} onClick={() => route === "privacy" ? onPrivacy() : route === "chats" ? onChats() : onOpen(`settings-${route}`)}><i>{ic}</i><span><b>{l}</b><small>{d}</small></span><em>›</em></button>)}<button className="danger-row" onClick={onLogout}>Sign out</button></section>;
}

function SettingsDetail({ type, settings, updateSettings, profile, onBack, onNotify }) {
  const titles = { subscriptions:"Subscriptions", "linked-devices":"Linked devices", account:"Account", lists:"Lists", chats:"Chats", appearance:"Appearance", broadcasts:"Broadcasts", notifications:"Notifications", storage:"Storage and data", parental:"Parental controls", accessibility:"Accessibility", language:"App language", help:"Help and feedback", invite:"Invite a friend", "accounts-centre":"Accounts Centre" };
  const title = titles[type] || "Settings";
  const toggle = (key, label, description) => <div className="setting-row"><i>◉</i><span><b>{label}</b><small>{description}</small></span><button className={`toggle ${settings[key] ? "on" : ""}`} onClick={() => updateSettings({ [key]: !settings[key] })}><i /></button></div>;
  if (type === "appearance") return <section className="screen"><Back title={title} onBack={onBack}/><h3>Theme</h3>{["system","light","dark"].map(v => <button className="setting-row" key={v} onClick={() => updateSettings({theme:v})}><i>◉</i><span><b>{v[0].toUpperCase()+v.slice(1)}</b><small>{settings.theme === v ? "Selected" : "Tap to use"}</small></span><em>{settings.theme === v ? "✓" : ""}</em></button>)}{toggle("largeText","Larger text","Increase interface text size")}{toggle("reducedMotion","Reduce motion","Use fewer animations")}</section>;
  if (type === "notifications") return <section className="screen"><Back title={title} onBack={onBack}/>{toggle("notifications","Notifications","Enable app notifications")}{toggle("messagePreview","Message previews","Show message text in notifications")}{toggle("sounds","Sounds","Play notification sounds")}</section>;
  if (type === "storage") return <section className="screen"><Back title={title} onBack={onBack}/>{toggle("dataSaver","Use less data for calls","Reduce media/call network usage")}{toggle("autoDownloadMedia","Auto-download media","Allow automatic media downloads")}{toggle("mediaVisibility","Media visibility","Show downloaded media in gallery")}</section>;
  if (type === "accessibility") return <section className="screen"><Back title={title} onBack={onBack}/>{toggle("highContrast","High contrast","Increase contrast for controls")}{toggle("largeText","Larger text","Use larger interface text")}{toggle("reducedMotion","Reduce motion","Reduce animations")}</section>;
  if (type === "language") return <section className="screen"><Back title={title} onBack={onBack}/>{["English","Hindi"].map(v => <button className="setting-row" key={v} onClick={() => updateSettings({language:v})}><i>◎</i><span><b>{v}</b><small>{settings.language === v ? "Selected" : "Tap to select"}</small></span><em>{settings.language === v ? "✓" : ""}</em></button>)}</section>;
  if (type === "privacy") return <Privacy lockEnabled={false} setLock={() => {}} onBack={onBack} onNotify={onNotify} settings={settings} updateSettings={updateSettings}/>;
  if (type === "chats") return <section className="screen"><Back title={title} onBack={onBack}/>{toggle("enterToSend","Enter is send","Press Enter to send messages")}{toggle("mediaVisibility","Media visibility","Show received media in gallery")}</section>;
  if (type === "linked-devices") return <section className="screen"><Back title={title} onBack={onBack}/><div className="empty">This browser session is the active web device.<br/><small>Firebase Auth manages the signed-in session. A separate device manager requires an Admin backend to revoke other refresh tokens.</small></div></section>;
  if (type === "subscriptions") return <section className="screen"><Back title={title} onBack={onBack}/><div className="empty">No subscription provider is connected yet.<br/><small>Connect Stripe/Google Play/App Store billing credentials to enable paid subscriptions.</small></div></section>;
  if (type === "accounts-centre") return <section className="screen"><Back title={title} onBack={onBack}/><div className="empty">Accounts Centre is external to this Firebase app.<br/><button className="green compact" onClick={() => window.open("https://accountscenter.meta.com/", "_blank", "noopener,noreferrer")}>Open Meta Accounts Centre</button></div></section>;
  if (type === "help") return <section className="screen"><Back title={title} onBack={onBack}/><button className="setting-row" onClick={() => window.open("https://faq.whatsapp.com/", "_blank", "noopener,noreferrer")}><i>?</i><span><b>Help centre</b><small>Open official WhatsApp Help Centre</small></span><em>↗</em></button><button className="setting-row" onClick={() => onNotify(`App: ${navigator.userAgent}`)}><i>ⓘ</i><span><b>Diagnostics</b><small>Show browser diagnostics</small></span><em>›</em></button></section>;
  if (type === "invite") return <section className="screen"><Back title={title} onBack={onBack}/><div className="empty"><p>Share your app with a friend.</p><button className="green compact" onClick={async()=>{const text=location.origin; if(navigator.share) await navigator.share({title:"WhatsApp Style",text, url:text}); else {await navigator.clipboard?.writeText(text); onNotify("App link copied");}}}>Share app</button></div></section>;
  if (type === "account") return <section className="screen"><Back title={title} onBack={onBack}/><div className="empty">Account profile is managed from your Profile screen.</div></section>;
  if (type === "lists" || type === "broadcasts" || type === "parental") return <section className="screen"><Back title={title} onBack={onBack}/><div className="empty">This section is ready for Firebase data. The current build stores UI preferences locally; contact/group list and broadcast delivery need their corresponding Firestore collections and server jobs.</div></section>;
  return <section className="screen"><Back title={title} onBack={onBack}/><div className="empty">Settings are available here.</div></section>;
}
function Back({title,onBack}) { return <div className="backbar"><button onClick={onBack}>‹</button><h1>{title}</h1></div>; }

function Profile({ profile, user, onBack, onSave, fileRef, setCropSrc, setShowCrop, showCrop, cropSrc }) {
  const [p, setP] = useState(profile);
  const [zoom, setZoom] = useState(1);
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [area, setArea] = useState(null);
  const [savingPhoto, setSavingPhoto] = useState(false);
  useEffect(() => setP(profile), [profile]);

  async function change(k, v) {
    const next = { ...p, [k]: v };
    setP(next);
    try { await onSave(next); } catch {}
  }
  function file(e) {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 8 * 1024 * 1024) return;
    const reader = new FileReader();
    reader.onload = () => { setCropSrc(reader.result); setShowCrop(true); setZoom(1); setCrop({ x: 0, y: 0 }); };
    reader.readAsDataURL(f);
  }
  async function cropAndSave() {
    if (!area) return;
    setSavingPhoto(true);
    try {
      const dataUrl = await getCroppedImage(cropSrc, area);
      let finalUrl = dataUrl;
      if (user) {
        const storageRef = ref(storage, `users/${user.uid}/profile/avatar.jpg`);
        await uploadString(storageRef, dataUrl, "data_url", { contentType: "image/jpeg" });
        finalUrl = await getDownloadURL(storageRef);
      }
      await change("photo", finalUrl);
      setShowCrop(false);
    } catch (e) {
      alert(`Photo save failed: ${e.message}`);
    } finally { setSavingPhoto(false); }
  }
  return <section className="screen"><div className="backbar"><button onClick={onBack}>‹</button><h1>Profile</h1></div><div className="profile-head"><div className="profile-photo">{p.photo ? <img src={p.photo} /> : <span>{p.name?.[0] || "R"}</span>}</div><label className="green compact">Upload / change photo<input ref={fileRef} hidden type="file" accept="image/*" onChange={file} /></label></div><div className="form">{[["name","Name","RIGHT"],["about","About","Set About"],["username","Username","no_name_12345"],["phone","Phone",user?.phoneNumber || "+91…"],["links","Links","Add links"]].map(([k,l,ph]) => <label key={k}>{l}<input value={p[k] || ""} placeholder={ph} onChange={(e) => change(k, e.target.value)} /></label>)}</div>{showCrop && <div className="crop-modal"><div className="crop-box"><div className="cropper"><Cropper image={cropSrc} crop={crop} zoom={zoom} aspect={1} onCropChange={setCrop} onZoomChange={setZoom} onCropComplete={(_, a) => setArea(a)} /></div><input type="range" min="1" max="3" step=".05" value={zoom} onChange={(e) => setZoom(Number(e.target.value))} /><button className="green" disabled={savingPhoto} onClick={cropAndSave}>{savingPhoto ? "Saving…" : "Crop & save"}</button><button onClick={() => setShowCrop(false)}>Cancel</button></div></div>}</section>;
}

async function getCroppedImage(src, pixelCrop) {
  const image = await new Promise((resolve, reject) => { const im = new Image(); im.onload = () => resolve(im); im.onerror = reject; im.src = src; });
  const canvas = document.createElement("canvas");
  const size = Math.max(1, Math.min(pixelCrop.width, pixelCrop.height));
  canvas.width = 512; canvas.height = 512;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(image, pixelCrop.x, pixelCrop.y, size, size, 0, 0, 512, 512);
  return canvas.toDataURL("image/jpeg", .9);
}

function Privacy({ lockEnabled, setLock, onBack, onNotify, settings = {}, updateSettings }) { return <section className="screen"><div className="backbar"><button onClick={onBack}>‹</button><h1>Privacy</h1></div><h3>Privacy</h3><div className="setting-row"><i>◉</i><span><b>Last seen</b><small>{settings.lastSeen || "Everyone"}</small></span><select value={settings.lastSeen || "Everyone"} onChange={e => updateSettings?.({lastSeen:e.target.value})}><option>Everyone</option><option>My contacts</option><option>Nobody</option></select></div><div className="setting-row"><i>◉</i><span><b>Profile photo</b><small>{settings.profilePhotoVisibility || "Everyone"}</small></span><select value={settings.profilePhotoVisibility || "Everyone"} onChange={e => updateSettings?.({profilePhotoVisibility:e.target.value})}><option>Everyone</option><option>My contacts</option><option>Nobody</option></select></div><div className="setting-row"><i>✓</i><span><b>Read receipts</b><small>Show when messages are read</small></span><button className={`toggle ${settings.readReceipts !== false ? "on" : ""}`} onClick={() => updateSettings?.({readReceipts: settings.readReceipts === false})}><i /></button></div><h3>Security</h3><div className="setting-row"><i>🔒</i><span><b>App lock</b><small>Fingerprint, face or device credential</small></span><button className={`toggle ${lockEnabled ? "on" : ""}`} onClick={() => setLock(!lockEnabled)}><i></i></button></div></section>; }
function ChatSettings({ lockEnabled, setLock, onBack, onNotify }) { return <section className="screen"><div className="backbar"><button onClick={onBack}>‹</button><h1>Chats</h1></div><button className="setting-row" onClick={() => onNotify("Chat backup opened")}><i>☁</i><span><b>Chat backup</b><small>Cloud backup</small></span><em>›</em></button><button className="setting-row" onClick={() => onNotify("Chat history opened")}><i>▱</i><span><b>Chat history</b><small>Manage chat history</small></span><em>›</em></button><div className="setting-row"><i>🔐</i><span><b>Chat lock</b><small>Protect chats with device security</small></span><button className={`toggle ${lockEnabled ? "on" : ""}`} onClick={() => setLock(!lockEnabled)}><i></i></button></div></section>; }

function MetaAI({ messages, setMessages, text, setText, busy, setBusy, onBack }) {
  async function send() {
    const t = text.trim();
    if (!t || busy) return;
    const next = [...messages, { role: "user", content: t }];
    setMessages(next); setText(""); setBusy(true);
    try {
      const response = await fetch("/api/meta-ai", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messages: next.slice(-20) }) });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error || "AI request failed");
      setMessages([...next, { role: "assistant", content: body.content }]);
    } catch (e) {
      setMessages([...next, { role: "assistant", content: `AI connection error: ${e.message}` }]);
    } finally { setBusy(false); }
  }
  return <section className="screen ai-screen"><div className="backbar"><button onClick={onBack}>‹</button><h1>Meta AI ✓</h1><a href="https://www.meta.ai/" target="_blank" rel="noreferrer">↗</a></div><div className="ai-messages">{messages.length === 0 && <div className="empty">Meta AI chat<br /><small>Real Meta Model API connection is used when the server API key is configured.</small></div>}{messages.map((m, i) => <div key={i} className={`bubble ${m.role}`}>{m.content}</div>)}{busy && <div className="bubble assistant">Thinking…</div>}</div><div className="ai-input"><input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} placeholder="Message Meta AI" /><button onClick={send} disabled={busy}>➤</button></div></section>;
}

createRoot(document.getElementById("root")).render(<App />);
